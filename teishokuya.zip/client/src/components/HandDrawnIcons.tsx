/**
 * Hand-drawn style SVG icons for the teishokuya website
 * Design: ほっこり絵日記スタイル
 * These icons add warmth and a handmade feel throughout the site
 */

export function RiceBowlIcon({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 36c0 0 2 14 20 14s20-14 20-14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M10 36h44" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M16 36c0-8 6-16 16-16s16 8 16 16" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M28 14c-1-4 0-6 2-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.5" />
      <path d="M34 16c-1-4 0-6 2-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.5" />
    </svg>
  );
}

export function ChopsticksIcon({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <line x1="20" y1="8" x2="28" y2="56" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="36" y1="8" x2="44" y2="56" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

export function SteamIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 24c0-4 4-4 4-8s-4-4-4-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
      <path d="M16 24c0-4 4-4 4-8s-4-4-4-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
      <path d="M24 24c0-4 4-4 4-8s-4-4-4-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
    </svg>
  );
}

export function OnigiriIcon({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M32 10L10 46h44L32 10z" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      <rect x="20" y="36" width="24" height="10" rx="2" fill="currentColor" opacity="0.3" />
    </svg>
  );
}

export function TeapotIcon({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="30" cy="40" rx="16" ry="12" stroke="currentColor" strokeWidth="2.5" />
      <path d="M30 28c0-6 4-10 4-10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
      <path d="M46 36c4-2 10-1 10 4" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M14 36c-4-2-6 0-6 4" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

export function LeafIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M6 26C6 26 8 6 26 6c0 0-2 20-20 20z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M6 26c6-6 12-12 20-20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" opacity="0.4" />
    </svg>
  );
}

export function HeartIcon({ className = "w-5 h-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 32 32" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 28S4 20 4 12c0-4 3-8 8-8 3 0 4 2 4 2s1-2 4-2c5 0 8 4 8 8 0 8-12 16-12 16z" opacity="0.6" />
    </svg>
  );
}

export function FishIcon({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 32c8-12 24-14 36-10-4-6-2-14-2-14s10 8 10 14-10 14-10 14 -2-8 2-14c-12 4-28 2-36-10z" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="42" cy="28" r="2" fill="currentColor" />
    </svg>
  );
}

/** Decorative scattered icons for section backgrounds */
export function ScatteredDecorations({ className = "" }: { className?: string }) {
  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none opacity-[0.06] ${className}`}>
      <div className="absolute top-[10%] left-[5%] rotate-12">
        <RiceBowlIcon className="w-12 h-12" />
      </div>
      <div className="absolute top-[30%] right-[8%] -rotate-6">
        <OnigiriIcon className="w-10 h-10" />
      </div>
      <div className="absolute bottom-[20%] left-[12%] rotate-[-15deg]">
        <ChopsticksIcon className="w-10 h-10" />
      </div>
      <div className="absolute top-[60%] right-[15%] rotate-[20deg]">
        <TeapotIcon className="w-12 h-12" />
      </div>
      <div className="absolute bottom-[10%] right-[30%] rotate-6">
        <FishIcon className="w-10 h-10" />
      </div>
      <div className="absolute top-[5%] right-[40%] -rotate-12">
        <LeafIcon className="w-8 h-8" />
      </div>
    </div>
  );
}
