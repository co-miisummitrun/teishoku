/**
 * CDN URLs for all generated images
 * Design: ほっこり絵日記スタイル - 手描き風の温かみのあるデザイン
 */

export const IMAGES = {
  owners: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663139257006/BOLkPesPGITCEuWw.jpg",
  yakizakana: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663139257006/fhNCSfKOTUQPMCid.jpg",
  tonkatsu: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663139257006/YYKpcslFsmJTxeaa.jpg",
  nikujaga: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663139257006/YOcGvAGeLIArTkse.jpg",
  interior: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663139257006/UaSxVndbeUZfzKcn.jpg",
  shogayaki: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663139257006/vzciVWcyfZAEpkyF.jpg",
  heroCooking: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663139257006/dLeCnHMNUfCrvOzv.jpg",
} as const;
